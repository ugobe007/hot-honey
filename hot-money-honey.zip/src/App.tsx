function App() {
  return (
    <div>
      <h1>Hello from Hot Money!</h1>
    </div>
  );
}

export default App;
